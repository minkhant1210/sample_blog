<?php require_once "core/base.php";?>
<?php require_once "core/functions.php"?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo $url ?>/assets/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo $url ?>/assets/vendor/feather-icons-web/feather.css">
    <link rel="stylesheet" href="<?php echo $url ?>/assets/vendor/animate_it/animate.css">
    <link rel="stylesheet" href="<?php echo $url ?>/assets/css/style.css">
</head>
<body>
<section class="container-fluid">
    <div class="row">
        <!-- SideBar Start -->
        <div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar py-3 mt-3">
            <div class="d-flex justify-content-between align-items-center brand-title">
                <div class="d-flex align-items-center">
                    <i class="feather-shopping-cart bg-primary text-white p-2 rounded mr-2"></i>
                    <span class="font-weight-bolder h4 mb-0 text-primary">MY SHOP</span>
                </div>
                <button class="hide-sidebar-btn  btn btn-primary btn-sm rounded text-white d-block d-lg-none">
                    <i class="feather-x text-black" style="font-size:1.5rem;"></i>
                </button>
            </div>
            <div class="nav-menu">
                <ul class="nav-group">
                    <li class="nav-header">
                        <p>Manage items</p>
                    </li>
                    <li class="nav-item active-list">
                        <a href="<?php echo $url ?>/index.php" class="nav-link"><i class="feather-home mr-1"></i>Dash Board</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo $url ?>/item_add.php" class="nav-link"><i class="feather-plus-circle mr-1"></i>Add Item</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo $url?>/item_list.php" class="nav-link d-flex justify-content-between align-items-center">
                            <span><i class="feather-list mr-1"></i>Item List</span>
                            <span class="badge badge-danger badge-pill shadow-lg">15</span>
                        </a>
                    </li>
                    <li class="nav-spacer p-4"></li>
                    <li class="nav-header">
                        <p>Manage Categories</p>
                    </li>
                    <li class="nav-item active-list">
                        <a href="<?php echo $url ?>/category_add.php" class="nav-link"><i class="feather-plus-circle mr-2"></i>Category Add</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo $url ?>/category_list.php" class="nav-link"><i class="feather-list mr-2"></i>Category List</a>
                    </li>
                    <li class="">
                        <a href="<?php echo $url ?>/logout.php" class="btn btn-outline-danger w-100"><i class="feather-log-out mr-2"></i>Log out</a>
                    </li>

                </ul>
            </div>
        </div>
        <!-- Content Start -->
        <div class="col-12 col-lg-9 col-xl-10 vh-100 py-3 content">
            <!-- Content_Header Start -->
            <div class="row header mb-4">
                <div class="col-12">
                    <div class="bg-primary p-2 rounded d-flex justify-content-between align-items-center">
                        <button class="show-sidebar-btn btn btn-primary d-block d-lg-none text-center">
                            <i class="feather-menu text-light" style="font-size: 1.5rem;"></i>
                        </button>

                        <form action="" method="post" class="d-none d-md-block">
                            <div class="form-inline">
                                <input type="text" class="form-control mr-2" placeholder="Search...">
                                <button class="btn btn-light">
                                    <i class="feather-search text-primary"></i>
                                </button>
                            </div>
                        </form>

                        <div class="dropdown">
                            <button class="btn btn-light dropdown-toggle p-1" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?php echo $url ?>/assets/img/<?php echo $_SESSION['user']['photo'] ?>" class="" width="25px" alt="">
                                <?php echo $_SESSION['user']['name'] ?>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <a class="dropdown-item" href="#">Something else here</a>
                                <hr>
                                <a class="dropdown-item text-danger" href="#">Log out</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Content_Header End -->