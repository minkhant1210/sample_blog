<?php
function con() {
    return mysqli_connect("localhost", "root", "", "blog");
}

$info = array(
    "name" => "sample blog",
    "short" => "sp",
    "description" => "some descriptions",
);

$url = "http://{$_SERVER['HTTP_HOST']}/wd_6/5_sample_blog";