<?php

//common start
function alert($data,$color="danger"){
    return "<p class='alert alert-$color'>$data</p>";
}

function runQuery($sql){
    if (mysqli_query(con(),$sql)){
        return true;
    } else {
        die("Database ERROR: ".mysqli_error());
    }
}

function redirect($location) {
    header("location:$location");
}
//common end

//auth start

function register() {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password === $cpassword) {
        $spassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$spassword')";
        if (runQuery($sql)) {
            redirect("login.php");
        }
    } else {
        return alert("Password & ConfirmPassword do not match");
    }
}

function login() {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE email='$email'";
    $query = mysqli_query(con(),$sql);
    $row = mysqli_fetch_assoc($query);
    if (!$row){
        return alert("Password or Email don't match");
    } else {
        if (!password_verify($password, $row['password'])){
            return alert("Password or Email don't match");
        } else {
            session_start();
            $_SESSION['user'] = $row;
            redirect("dashboard.php");
        }
    }
}

//auth end