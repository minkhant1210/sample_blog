<?php require_once "core/auth.php";?>
<?php include "template/header.php";?>

<h4>This is dashboard page</h4>

<?php include "template/footer.php"; ?>
